<?php 
define('ENV','development'); //AMBIENTE - Desenvolvimento

define('URL','http://127.0.0.1/projetos/blog_/'); //URL raiz

define('DIR', dirname(__FILE__)); //Diretório raiz
?>
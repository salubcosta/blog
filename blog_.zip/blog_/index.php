<?php
require_once 'config.php';

$core = new core();

$core->run();
?>
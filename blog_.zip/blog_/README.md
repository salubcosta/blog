# blog

Projeto: Blog pessoal que versará sobre assuntos relacionados à área de TI

===

## Ferramentas
Servidor WEB:
PHP Version 7.2.9
Apache/2.4.34
Servidor de banco de dados:
Tipo de servidor: MariaDB
Versão do servidor: 10.1.35



